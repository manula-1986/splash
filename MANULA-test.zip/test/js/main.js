

function register(){
    $('#reg-btn').click(function(e) {
        e.preventDefault();
        var first_name = $('#firstname').val();
        var last_name = $('#lastname').val();
        var email = $('#email').val();
        var password = $('#password').val();
        var mobile = $('#mobile').val();

        $(".error").remove();
    
        if (first_name.length < 1) {
          $('#firstname').after('<span class="error">This field is required</span>');
        }
        if (last_name.length < 1) {
          $('#lastname').after('<span class="error">This field is required</span>');
        }
        if (mobile.length < 1) {
            $('#mobile').after('<span class="error">This field is required</span>');
          }
        if (email.length < 1) {
          $('#email').after('<span class="error">This field is required</span>');
        } else {
          var regEx = /^[A-Z0-9][A-Z0-9._%+-]{0,63}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/;
          var validEmail = regEx.test(email);
          if (!validEmail) {
            $('#email').after('<span class="error">Enter a valid email</span>');
          }
        }
        if (password.length < 8) {
          $('#password').after('<span class="error">Password must be at least 8 characters long</span>');
        }
      });
}
function signin(){
    $('#btn-login').click(function(e) {
        e.preventDefault();
        var password = $('#login-password').val();
        var mobile = $('#login-mobile').val();

        $(".error").remove();
    
        if (mobile.length < 1 || mobile.length < 10) {
            $('#login-mobile').after('<span class="error">This field is required</span>');
          }
          else {
            var regnum = /^[0-9]+$/;
            var validnum = regnum.test(login-mobile);
            if (!validnum) {
              $('#email').after('<span class="error">Enter a valid email</span>');
            }
          }

        if (password.length < 8) {
          $('#login-password').after('<span class="error">Password must be at least 8 characters long</span>');
        }
      });
}
$( document ).ready(function() {
    register();
    signin();
});